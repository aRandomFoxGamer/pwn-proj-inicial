class Mechanics{
constructor(x, y){
    this.x = x;
    this.y = y;
    this.animation;
    this.isUP = false;
    this.isRIGHT = false;
    this.isDOWN = false;
    this.isMoving = false;
    this.playerup = loadImage("./assets/playerup/playerupframe1.png");
    this.playerright = loadImage("./assets/playerright/playerrightframe1.png");
    this.playerdown = loadImage("./assets/playerdown/playerdownframe1.png");
    this.playerleft = loadImage("./assets/playerleft/playerleftframe1.png");
    this.playerupmoving = loadAnimation("./assets/playerup/playerupframe1.png","./assets/playerup/playerupframe2.png", "./assets/playerup/playerupframe3.png", "./assets/playerup/playerupframe4.png");
    this.playerrightmoving = loadAnimation("./assets/playerright/playerrightframe1.png","./assets/playerright/playerrightframe2.png", "./assets/playerright/playerrightframe3.png", "./assets/playerright/playerrightframe4.png");
    this.playerdownmoving = loadAnimation("./assets/playerdown/playerdownframe1.png","./assets/playerdown/playerdownframe2.png", "./assets/playerdown/playerdownframe3.png", "./assets/playerdown/playerdownframe4.png");
    this.playerleftmoving = loadAnimation("./assets/playerleft/playerleftframe1.png","./assets/playerleft/playerleftframe2.png", "./assets/playerleft/playerleftframe3.png", "./assets/playerleft/playerleftframe4.png");

}

show(){
this.whenOnGame();

drawSprites()
}

whenOnGame(){
    if(keyDown("w")){
    this.animation.y -= 5;
    this.isUP = true;
    this.isDOWN = false;
    this.isRIGHT = false;
    this.isLEFT = false;
    this.isMoving = true;
    this.animation.changeAnimation("movingup");
    }
    else if(keyDown("s")){
    this.animation.y += 5;
    this.isDOWN = true;
    this.isUP = false;
    this.isRIGHT = false;
    this.isLEFT = false;
    this.isMoving = true;
    this.animation.changeAnimation("movingdown");
    }

    else if(keyDown("a")){
    this.animation.x -= 5;
    this.isLEFT = true;
    this.isRIGHT = false;
    this.isUP = false;
    this.isDOWN = false;
    this.isMoving = true;
    this.animation.changeAnimation("movingleft");
    }

    else if(keyDown("d")){
    this.animation.x += 5;
    this.isRIGHT = true;
    this.isLEFT = false;
    this.isUP = false;
    this.isDOWN = false;
    this.isMoving = true;
    this.animation.changeAnimation("movingright");
    }
    else{
    this.isMoving = false;
}

    if(this.isUP && this.isMoving === false) {
     this.animation.changeImage("up");
    }
    else if(this.isDOWN && this.isMoving === false) {
        this.animation.changeImage("down");
    }
    else if(this.isRIGHT && this.isMoving === false) {
        this.animation.changeImage("right");
    }
    else if(this.isLEFT && this.isMoving === false) {
        this.animation.changeImage("left");
    }


    if(keyDown("w")&&keyDown("shift")){
        this.animation.y -= 6.5;
        this.isUP = true;
        this.isDOWN = false;
        this.isRIGHT = false;
        this.isLEFT = false;
        this.isMoving = true;
        this.animation.changeAnimation("movingup");
        }
        else if(keyDown("s")&&keyDown("shift")){
        this.animation.y += 6.5;
        this.isDOWN = true;
        this.isUP = false;
        this.isRIGHT = false;
        this.isLEFT = false;
        this.isMoving = true;
        this.animation.changeAnimation("movingdown");
        }
    
        else if(keyDown("a")&&keyDown("shift")){
        this.animation.x -= 6.5;
        this.isLEFT = true;
        this.isRIGHT = false;
        this.isUP = false;
        this.isDOWN = false;
        this.isMoving = true;
        this.animation.changeAnimation("movingleft");
        }
    
        else if(keyDown("d")&&keyDown("shift")){
        this.animation.x += 6.5;
        this.isRIGHT = true;
        this.isLEFT = false;
        this.isUP = false;
        this.isDOWN = false;
        this.isMoving = true;
        this.animation.changeAnimation("movingright");
        }
        else{
        this.isMoving = false;
    }
}

createAllSprites(){
this.animation = createSprite(this.x, this.y);
this.animation.addImage("down",this.playerdown);
this.animation.addImage("up",this.playerup);
this.animation.addImage("right",this.playerright);
this.animation.addImage("left",this.playerleft);

this.animation.addAnimation("movingup",this.playerupmoving);
this.animation.addAnimation("movingdown", this.playerdownmoving);
this.animation.addAnimation("movingright",this.playerrightmoving);
this.animation.addAnimation("movingleft",this.playerleftmoving);
this.animation.scale = 2.5;
}
}