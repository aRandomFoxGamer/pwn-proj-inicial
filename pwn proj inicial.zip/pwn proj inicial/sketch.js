var background;
var player;
function preload(){
background = loadImage("./assets/fundoxadrex.png");

}

function setup(){
createCanvas(windowWidth, windowHeight)

player = new Mechanics(width / 2, height / 2);
player.createAllSprites();
}

function draw() {

 for(var i = -50; i < width; i += 200){
  for(var j = -50; j < height; j += 200){
    image(background, i, j);
  background.scale = 0.5;
  }
  
 }
player.show();
}
